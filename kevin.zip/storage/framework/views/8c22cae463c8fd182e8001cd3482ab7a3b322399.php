<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center">
        <h1 class="display-4"><b><?php echo e($title); ?></b></h1>
        <p class="text-info">KEVBLOG is a simple application which you can share, post your story 
            or anything that you want. You can register for free. This blog is created by a <abbr class='text-primary' title="Kevin Holgado (Jr. Web Developer)">K.H.</abbr>
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>