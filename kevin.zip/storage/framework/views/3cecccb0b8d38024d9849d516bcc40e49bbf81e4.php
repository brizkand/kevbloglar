<div class="container-fluid">
    <br>
    <footer class="footer text-center">Copyright &copy; <?php echo e(date('Y')); ?> Kevin Holgado All rights reserved</footer>
    <br>
</div>
